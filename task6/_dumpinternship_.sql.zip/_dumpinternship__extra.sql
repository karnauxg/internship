
--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `Result`
--
ALTER TABLE `Result`
  ADD UNIQUE KEY `StudentID` (`ID`,`StudentID`);

--
-- Індекси таблиці `Students`
--
ALTER TABLE `Students`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `StudentID` (`ID`,`StudentID`);
