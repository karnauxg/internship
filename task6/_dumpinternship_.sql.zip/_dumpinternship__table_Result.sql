
-- --------------------------------------------------------

--
-- Структура таблиці `Result`
--

CREATE TABLE `Result` (
  `ID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `Task1` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Task2` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Task3` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Task4` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп даних таблиці `Result`
--

INSERT INTO `Result` (`ID`, `StudentID`, `Task1`, `Task2`, `Task3`, `Task4`) VALUES
(1, 1, 'Done', 'Done', 'Done', 'Done'),
(2, 2, 'Done', 'Done', 'Done', 'Done'),
(3, 3, 'Done', 'Done', 'Done', 'Done'),
(4, 4, 'Done', 'Done', 'Done', 'Done'),
(5, 5, 'Done', 'Done', 'Done', 'Done'),
(6, 7, 'Done', 'Done', 'Done', 'Done'),
(7, 8, 'Done', 'not completed', 'Done', 'Done'),
(8, 9, 'Done', 'Done', 'Done', 'Done'),
(9, 10, 'Done', 'Done', 'Done', 'Done'),
(10, 11, 'Done', 'Done', 'Done', 'Done'),
(11, 14, 'Done', 'Done', 'Done', 'Done'),
(12, 16, 'Done', 'Done', 'Done', 'Done'),
(13, 18, 'Done', 'Done', 'Done', 'Done'),
(14, 19, 'Done', 'Done', 'Done', 'Done'),
(15, 20, 'Done', 'Done', 'Done', 'Done'),
(16, 21, 'Done', 'Done', 'Done', 'Done'),
(17, 22, 'Done', 'Done', 'Done', 'Done'),
(18, 23, 'Done', 'Done', 'Done', 'Done'),
(19, 24, 'Done', 'Done', 'Done', 'Done'),
(20, 26, 'Done', 'Done', 'Done', 'Done'),
(21, 27, 'Done', 'Done', 'Done', 'Done');
